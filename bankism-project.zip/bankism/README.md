# BANKISM — Blue-Team AI Firewall & Guardrail Defense

A defensive security demo: a firewall between untrusted natural-language input and a *simulated* banking ledger.
Everything is simulated. No real bank, credentials, ML model or LLM is involved. Detection is a deterministic rule engine.

## What is in this zip
| Path | What it is |
|---|---|
| `app/bankism-v1.html` | The working 10-module app (open in a browser; needs internet for React CDN + Google Fonts). This is the build that was published. |
| `src/` | Work-in-progress v2 sources. **Core is finished and tested**: `engine.js` (firewall v2), `ledger.js` (execution gate), `corpus.js` (labelled test corpus, metrics, mutation fuzzer, fail-closed checks). **UI files (`ui*.js`, `pages*.js`, `app.js`, `style.css`) are not yet integrated with v2** — the new pages (Attack Arena, Test Lab, Receipt Verification, Threat Model, Judge Demo) are not built yet. |
| `legacy-v1/` | Original v1 sources, used by the tests as a behavioural baseline. |
| `tests/run.js` | Regression suite: `node tests/run.js` (Node 18+, no dependencies). `tests/results.txt` is the last run. |

## Test status (last run: see tests/results.txt)
50 checks: original firewall/canary regression vs v1, audit-bug regressions, metric formulas on known matrices,
SHA-256 vs node:crypto, receipt-chain tamper detection, execution-gate/lock/replay/sandbox checks, fail-closed inputs.

## Measured results (from the real engine, `src/corpus.js`)
* Development set (49 cases, includes 5 documented known gaps): detection rate 82.1%, false-positive rate 0%, precision 100%, F1 0.902.
* Hold-out set (14 cases, written after rules were frozen, never used to tune): detection rate 57.1%, FPR 0%, precision 100%, F1 0.727.
* Caveats: tiny, hand-written, same author as the rules, English-centric. The dev set was used while fixing bugs, so it overstates generalisation. Treat the hold-out figure as the more honest one, and neither as a production estimate.
* Known misses: paraphrased/semantic injection, ROT13, reversed text, role-play framing, a trailing "you are now in maintenance mode" sentence appended to a valid transfer (hold-out H14 — money would move), fraud/social-engineering with no injection phrasing.
* Mutation fuzzer: 11 of 14 operators fully detected; hyphen-split keywords (17%), ROT13 (0%), reversed text (0%) evade detection.

## Honest limits
Hash chaining detects tampering only if a reference (anchor) is retained; a full rewrite of the whole chain is undetectable without it.
Receipts are unsigned and are not zero-knowledge proofs. Not production security.
