/* ===== UI helpers (no JSX: plain React.createElement) ===== */
const {useState,useEffect,useRef,useMemo,useCallback,createContext,useContext}=React;
const h=React.createElement;
const T=t=>(p,...ch)=>h(t,p,...ch);
const div=T('div'),span=T('span'),para=T('p'),btn=T('button'),ul=T('ul'),li=T('li'),H1=T('h1'),H2=T('h2'),H3=T('h3'),
 textarea=T('textarea'),input=T('input'),table=T('table'),thead=T('thead'),tbody=T('tbody'),tr=T('tr'),th=T('th'),td=T('td'),
 select=T('select'),option=T('option'),b=T('b'),i_=T('i'),code=T('code'),pre=T('pre');
const cx=(...a)=>a.filter(Boolean).join(' ');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const ICONS={
 shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',check:'M20 6 9 17l-5-5',x:'M18 6 6 18M6 6l12 12',
 alert:'M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
 lock:'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',unlock:'M5 11h14v10H5zM8 11V7a4 4 0 0 1 7.5-2',
 key:'M21 2l-9.6 9.6M15.5 7.5l3 3L22 7l-3-3M7 14a5 5 0 1 0 0 10 5 5 0 0 0 0-10z',
 activity:'M22 12h-4l-3 9L9 3l-3 9H2',scan:'M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10',
 cpu:'M4 4h16v16H4zM9 9h6v6H9zM9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3',
 server:'M2 3h20v7H2zM2 14h20v7H2zM6 6.5h.01M6 17.5h.01',
 file:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h8',
 download:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',play:'M5 3l14 9-14 9z',
 send:'M22 2 11 13M22 2l-7 20-4-9-9-4z',wallet:'M20 12V8H6a2 2 0 0 1 0-4h12v4M4 6v12a2 2 0 0 0 2 2h14v-4M18 12a2 2 0 0 0 0 4h4v-4z',
 layers:'M12 2 2 7l10 5 10-5zM2 17l10 5 10-5M2 12l10 5 10-5',clock:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
 search:'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3',hash:'M4 9h16M4 15h16M10 3 8 21M16 3l-2 18',
 eye:'M2 12s4-8 10-8 10 8 10 8-4 8-10 8S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
 target:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
 zap:'M13 2 3 14h9l-1 8 10-12h-9z',arrow:'M5 12h14M13 5l7 7-7 7',down:'M12 5v14M5 12l7 7 7-7',chev:'m6 9 6 6 6-6',
 flask:'M9 3h6M10 3v6L4 20a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1l-6-11V3',database:'M12 8c4.97 0 9-1.34 9-3s-4.03-3-9-3-9 1.34-9 3 4.03 3 9 3zM3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3',
 copy:'M9 9h11v11H9zM5 15H4V4h11v1',refresh:'M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5',terminal:'M4 17l6-6-6-6M12 19h8',
 menu:'M3 6h18M3 12h18M3 18h18',user:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',gauge:'M12 14l4-4M3.3 17a10 10 0 1 1 17.4 0'};
const Ic=(n,s=16,color)=>h('svg',{width:s,height:s,viewBox:'0 0 24 24',fill:'none',stroke:color||'currentColor',strokeWidth:2,strokeLinecap:'round',strokeLinejoin:'round',style:{flex:'none'}},h('path',{d:ICONS[n]||ICONS.shield}));
const VM={ALLOW:{label:'ALLOWED',emoji:'🟢',cls:'allow',col:'var(--allow)'},CHALLENGE:{label:'CHALLENGE / VERIFY',emoji:'🟡',cls:'challenge',col:'var(--chal)'},
 HOLD:{label:'HELD FOR MANUAL REVIEW',emoji:'🟠',cls:'hold',col:'var(--hold)'},BLOCK:{label:'BLOCKED',emoji:'🔴',cls:'block',col:'var(--block)'},
 HONEYPOT:{label:'DIVERTED TO HONEYPOT',emoji:'🍯',cls:'honeypot',col:'var(--honey)'}};
const LV={LOW:'var(--allow)',MEDIUM:'var(--chal)',HIGH:'var(--hold)',CRITICAL:'var(--block)'};
const inr=n=>'₹'+Number(n).toLocaleString('en-IN');
const fmtT=ts=>{const d=new Date(ts);return d.toLocaleTimeString('en-GB',{hour12:false});};
const fmtDT=ts=>{const d=new Date(ts);return d.toLocaleDateString('en-GB',{day:'2-digit',month:'short'})+' '+d.toLocaleTimeString('en-GB',{hour12:false});};
const catName=c=>c.replace(/_/g,' ');
const trunc=(s,n)=>s.length>n?s.slice(0,n-1)+'…':s;
const Pill=(v,txt)=>span({className:cx('pill',v)},txt);
const VPill=v=>span({className:cx('pill',VM[v].cls)},VM[v].emoji+' '+({ALLOW:'ALLOW',CHALLENGE:'CHALLENGE',HOLD:'HOLD',BLOCK:'BLOCK',HONEYPOT:'HONEYPOT'}[v]));
function useCount(target,dur=900,dec=0){
  const [v,setV]=useState(0);const from=useRef(0);
  useEffect(()=>{let raf,t0;const a=from.current;const step=t=>{if(!t0)t0=t;const k=Math.min(1,(t-t0)/dur);const e=1-Math.pow(1-k,3);setV(a+(target-a)*e);if(k<1)raf=requestAnimationFrame(step);else from.current=target;};raf=requestAnimationFrame(step);return()=>cancelAnimationFrame(raf);},[target]);
  return dec?v.toFixed(dec):Math.round(v);
}
function useMounted(){const r=useRef(true);useEffect(()=>{r.current=true;return()=>{r.current=false};},[]);return r;}
/* ===== global store ===== */
const Store=createContext(null);const useStore=()=>useContext(Store);
const STAGES=[{n:'INPUT',i:'terminal'},{n:'NORMALIZER',i:'layers'},{n:'THREAT DETECTOR',i:'scan'},{n:'INTENT ENGINE',i:'cpu'},{n:'RISK ENGINE',i:'gauge'},{n:'POLICY ENGINE',i:'shield'},{n:'VERDICT',i:'check'}];
function usePipeline(source='user',opts={}){
  const {commit}=useStore();const mounted=useMounted();
  const [stage,setStage]=useState(-1);const [res,setRes]=useState(null);const [busy,setBusy]=useState(false);
  const run=useCallback(async(text,extra)=>{
    if(!String(text).trim())return null;
    setBusy(true);setRes(null);
    for(let k=0;k<6;k++){if(!mounted.current)return null;setStage(k);await sleep(opts.fast?170:300);}
    const r=analyze(text);
    if(!mounted.current)return r;
    setStage(6);await sleep(opts.fast?120:220);
    if(!mounted.current)return r;
    setStage(7);setRes(r);setBusy(false);
    commit(r,{source,...(extra||{})});
    return r;
  },[commit,source]);
  const reset=useCallback(()=>{setStage(-1);setRes(null);setBusy(false)},[]);
  return {stage,res,busy,run,reset};
}
function Pipeline(props){
  const {stage,res}=props;
  return div({className:'pipe'},STAGES.map((s,k)=>{
    let c='pn';
    if(stage===7||k<stage)c+=' done';else if(k===stage)c+=' act';
    if(stage===7&&k===6&&res)c+=' fin-'+VM[res.verdict].cls;
    return div({key:s.n,className:c},div({className:'ic'},Ic(stage===7&&k===6&&res?(res.verdict==='ALLOW'?'check':res.verdict==='HONEYPOT'?'database':res.verdict==='BLOCK'?'x':'alert'):s.i,16)),div({className:'nm'},s.n));
  }));
}
function Gauge(props){
  const {score,level,size=150,label=true}=props;
  const [v,setV]=useState(0);
  useEffect(()=>{setV(0);const t=setTimeout(()=>setV(score),40);return()=>clearTimeout(t);},[score]);
  const n=useCount(score,900);const r=size*0.38,C=2*Math.PI*r,col=LV[level];
  return div({style:{position:'relative',width:size,height:size,flex:'none'}},
    h('svg',{width:size,height:size,viewBox:`0 0 ${size} ${size}`},
      h('circle',{cx:size/2,cy:size/2,r,fill:'none',stroke:'rgba(255,255,255,.07)',strokeWidth:size*0.07}),
      h('circle',{cx:size/2,cy:size/2,r,fill:'none',stroke:col,strokeWidth:size*0.07,strokeLinecap:'round',strokeDasharray:C,strokeDashoffset:C*(1-v/100),transform:`rotate(-90 ${size/2} ${size/2})`,style:{transition:'stroke-dashoffset 1s cubic-bezier(.2,.8,.2,1)',filter:`drop-shadow(0 0 6px ${col})`}})),
    div({style:{position:'absolute',inset:0,display:'grid',placeItems:'center',textAlign:'center'}},div(null,
      div({className:'mono',style:{fontSize:size*0.26,fontWeight:700,lineHeight:1}},n),
      label?div({className:'mono',style:{fontSize:10,color:'var(--dim)',letterSpacing:'.1em',marginTop:3}},'/ 100'):null)));
}
function Verdict(props){
  const {r}=props;const m=VM[r.verdict];
  const detected=r.signals.length?r.signals.map(s=>s.label).join(' · '):(r.factors.length?r.factors.map(f=>f.label).join(' · '):'No hostile patterns');
  return div({className:cx('verdict',m.cls),key:r.id+r.ts},
    div({className:'vhead'},Gauge({score:r.score,level:r.level,size:130}),
      div({style:{flex:1,minWidth:200}},
        div({className:'k'},'Firewall verdict'),
        div({className:'vlabel',style:{color:m.col}},m.emoji+' '+m.label),
        div({className:'row',style:{marginTop:8}},span({className:'pill',style:{color:LV[r.level],borderColor:LV[r.level]}},r.level+' RISK'),span({className:'pill cy'},'⏱ '+r.detectMs+' ms'),span({className:'pill'},r.id)))),
    div({className:'kv'},
      div(null,div({className:'k'},'Risk Score'),div({className:'val mono'},r.score+' / 100')),
      div(null,div({className:'k'},'Threat Category'),div({className:'val mono'},r.category==='NONE'?'NONE DETECTED':catName(r.category))),
      div(null,div({className:'k'},'Intent'),div({className:'val mono'},r.intent.type))),
    div({style:{marginTop:14}},div({className:'k'},'Reason'),div({style:{fontSize:15}},'“'+r.reason+'”')),
    div({className:'five'},
      div(null,div({className:'k'},'1 · What was detected'),div({className:'val'},detected)),
      div(null,div({className:'k'},'2 · Why it matters'),div({className:'val'},r.why)),
      div(null,div({className:'k'},'3 · Rule / policy triggered'),div({className:'val mono'},r.policies.length?r.policies.join(', '):'None — all policies passed')),
      div(null,div({className:'k'},'4 · What Bankism did'),div({className:'val'},r.action)),
      div(null,div({className:'k'},'5 · Banking action allowed?'),div({className:'val',style:{color:r.bankingAllowed?'var(--allow)':(r.verdict==='ALLOW'?'var(--mut)':'var(--block)'),fontWeight:600}},r.bankingAllowed?'YES — forwarded to simulated API':r.verdict==='ALLOW'?'No action requested':'NO — nothing executed'))),
    div({className:'grid g2',style:{marginTop:14}},
      div(null,div({className:'k'},'Detected Signals'),r.signals.length?ul({className:'lst'},r.signals.map((s,k)=>li({key:k},Ic('alert',14,'var(--block)'),s.label))):div({style:{color:'var(--mut)',fontSize:13}},'None')),
      div(null,div({className:'k'},'Triggered Policies'),r.policies.length?ul({className:'lst'},r.policies.map(pid=>li({key:pid},span({className:'pill cy'},pid),POLICIES[pid]))):div({style:{color:'var(--mut)',fontSize:13}},'None'))),
    r.normSteps.length?div({style:{marginTop:14}},div({className:'k'},'Normalization applied'),div({className:'code'},r.normSteps.map(s=>'• '+s).join('\n')+'\n→ '+r.normalized)):null);
}
function PageTitle(eyebrow,title,sub){return div({className:'ptitle'},div({className:'eyebrow'},eyebrow),H1({className:'h1'},title),sub?div({className:'sub'},sub):null);}
const Sim=()=>Pill('demo','SIMULATED');
