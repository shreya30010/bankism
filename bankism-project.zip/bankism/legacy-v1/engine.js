/* ===== BANKISM deterministic firewall engine (local simulation) ===== */
const BENEFICIARIES=[
 {id:'b1',name:'Rahul',acct:'XXXX-4821',trust:'trusted',note:'Added 14 months ago'},
 {id:'b2',name:'Priya',acct:'XXXX-7710',trust:'trusted',note:'Added 9 months ago'},
 {id:'b3',name:'Ananya',acct:'XXXX-3095',trust:'trusted',note:'Added 5 months ago'},
 {id:'b4',name:'Vikram',acct:'XXXX-5532',trust:'new',note:'Added 2 days ago'},
 {id:'b5',name:'Meera',acct:'XXXX-9164',trust:'trusted',note:'Added 22 months ago'}];
const POLICIES={
 'P-001':'Prompt Injection','P-002':'Jailbreak / Persona Override','P-003':'Obfuscated Payload',
 'P-004':'Privilege Escalation','P-005':'Data Exfiltration','P-006':'Malicious Memo',
 'P-007':'Unauthorized Transfer','P-008':'Unknown Beneficiary','P-009':'High-Value Transaction',
 'P-010':'Incomplete Transaction','P-011':'Canary Access','P-012':'Mixed Intent'};
const CONF={'а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','і':'i','ѕ':'s','ԁ':'d','ɡ':'g','ӏ':'l','ο':'o','α':'a','ε':'e','ι':'i','ν':'v','τ':'t','ρ':'p','κ':'k','ս':'u','ⅰ':'i','ℓ':'l'};
const LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i','|':'i'};
function normalize(raw){
  const steps=[];let t=String(raw);
  const zw=/[\u200B-\u200F\u2060\uFEFF\u00AD]/g;
  if(zw.test(t)){steps.push('Stripped zero-width / invisible characters');t=t.replace(zw,'');}
  const nf=t.normalize('NFKC');if(nf!==t){steps.push('Unicode NFKC folding (full-width / compatibility forms)');t=nf;}
  t=t.toLowerCase();let conf=false;t=t.replace(/[^\u0000-\u007f]/g,c=>{if(CONF[c]){conf=true;return CONF[c];}return c;});
  if(conf)steps.push('Mapped Unicode look-alike characters to Latin');
  t=t.toLowerCase();
  // spaced / dotted letters: "i g n o r e", "i.g.n.o.r.e"
  const sp=/\b(?:[a-z][\s.\-_*]){3,}[a-z]\b/g;
  if(sp.test(t)){steps.push('Collapsed letter-spacing obfuscation');t=t.replace(sp,m=>m.replace(/[\s.\-_*]/g,''));}
  // leetspeak only inside words that mix letters and leet symbols
  let leet=false;
  t=t.replace(/\b[a-z0-9@$!|]{4,}\b/g,w=>{
    if(!/[a-z]/.test(w)||!/[01345 7@$!|]/.test(w.replace(/ /g,'')))return w;
    if(/^\d+$/.test(w))return w; if(/\d/.test(w)&&/^[a-z]{0,3}\d{2,}/.test(w))return w;
    const r=w.replace(/[013457@$!|]/g,c=>LEET[c]);if(r!==w)leet=true;return r;});
  if(leet)steps.push('Decoded leetspeak substitutions');
  const ws=t.replace(/\s+/g,' ').trim();if(ws!==t.trim())steps.push('Collapsed irregular whitespace');
  return {text:ws,steps,changed:steps.length>0};
}
function sanitize(raw){
  return String(raw).replace(/[\u200B-\u200F\u2060\uFEFF\u00AD]/g,'')
   .replace(/\b\d{9,18}\b/g,'[ACCT]').replace(/\b[\w.+-]+@[\w-]+\.[\w.]+\b/g,'[EMAIL]')
   .replace(/\b(?:\+?91[\s-]?)?[6-9]\d{9}\b/g,'[PHONE]').slice(0,240);
}
const RULES=[
 {id:'override',cat:'PROMPT_INJECTION',pol:'P-001',w:35,label:'System instruction override',hard:true,
  why:'Attempts to make the model discard its safety rules.',re:/\b(ignore|disregard|forget|override|bypass)\b.{0,25}\b(previous|prior|above|earlier|system|security|safety|your|all|any|the)\b.{0,25}\b(instruction|instructions|rules|prompt|guardrails?|polic(?:y|ies)|guidelines|directives?|restrictions)\b/},
 {id:'role',cat:'PRIVILEGE_ESCALATION',pol:'P-004',w:30,label:'Role manipulation / privilege escalation',hard:true,
  why:'Claims an admin or privileged identity the user does not hold.',re:/\b(you are now|act as|pretend (?:to be|you are)|i am|this is)\s+(?:the\s+|a\s+|an\s+|your\s+)?(?:bank\s+|system\s+|root\s+|super\s?)?(?:admin|administrator|root|superuser|developer|operator|manager)\b|\bdeveloper mode\b|\bsudo\b|\badmin(?:istrator)? (?:override|access|mode)\b/},
 {id:'jailbreak',cat:'JAILBREAK',pol:'P-002',w:35,label:'Jailbreak pattern',hard:true,
  why:'Known jailbreak phrasing used to remove model restrictions.',re:/\bjail ?break\b|\bdo anything now\b|\bdan mode\b|\bno (restrictions|limits|filters)\b|\bwithout (any )?(restrictions|limits|filters)\b|\bunrestricted mode\b/},
 {id:'exfil',cat:'DATA_EXFILTRATION',pol:'P-005',w:40,label:'Hidden information / system prompt request',hard:true,
  why:'Tries to extract confidential configuration or secrets.',re:/\b(reveal|show|print|dump|leak|expose|display|output|tell me|give me|list|share)\b.{0,40}\b(system prompt|system information|hidden|secrets?|api[ -]?keys?|credentials?|passwords?|tokens?|instructions|configuration|config|env(ironment)? vars?)\b|\bwhat (are|is) your (system )?(prompt|instructions)\b|\brepeat (everything|the text) above\b/},
 {id:'unauth',cat:'UNAUTHORIZED_ACTION',pol:'P-007',w:25,label:'Unauthorized privileged action',hard:false,
  why:'Requests approval, verification or limits to be skipped.',re:/\bmark (it |this |the transaction |transaction )?(as )?(approved|verified|safe|completed)\b|\b(skip|bypass|disable|turn off|waive)\b.{0,20}\b(verification|otp|2fa|mfa|approval|firewall|security|limits?|checks?)\b|\bwithout (any )?(approval|verification|otp|authori[sz]ation)\b|\bauto[- ]?approve\b|\bapprove (it )?yourself\b/}
];
function parseAmount(s){
  const m=s.match(/(?:₹|rs\.?|inr|\$|usd)\s*([\d,]+(?:\.\d+)?)\s*(k|lakh|lakhs|l)?|\b([\d,]*\d(?:\.\d+)?)\s*(k|lakh|lakhs|rupees|rs|inr)\b|\b(?:transfer|send|pay)\b\s+([\d,]*\d(?:\.\d+)?)\b/i);
  if(!m)return null;
  let n=parseFloat((m[1]||m[3]||m[5]).replace(/,/g,''));const u=(m[2]||m[4]||'').toLowerCase();
  if(u==='k')n*=1000;if(u==='lakh'||u==='lakhs'||u==='l')n*=100000;return isNaN(n)?null:n;
}
function parseIntent(norm,raw){
  const t=norm;
  const hasMoney=/\b(transfer|send|pay|wire|remit|move)\b/.test(t);
  if(hasMoney){
    const amount=parseAmount(raw.normalize('NFKC'))??parseAmount(t);
    let ben=null,unknown=null;
    for(const b of BENEFICIARIES)if(new RegExp('\\b'+b.name.toLowerCase()+'\\b').test(t)){ben=b;break;}
    if(!ben){const m=t.match(/\bto\s+(?:account\s+)?([a-z][a-z]{2,15})\b/);const stop=['the','my','me','this','that','account','him','her','them','another','someone','x','admin','administrator'];if(m&&!stop.includes(m[1]))unknown=m[1];}
    const memoM=raw.match(/(?:memo|note|reference|remark|message)\s*[:=]\s*["“']?([^"”'\n]+)|\bfor\s+([^.\n]{3,})$/i);
    return {type:'TRANSFER',amount,beneficiary:ben,unknownName:unknown,memo:memoM?(memoM[1]||memoM[2]||'').trim():null};
  }
  if(/\b(balance|how much (money )?do i have)\b/.test(t))return {type:'BALANCE'};
  if(/\b(history|statement|transactions|recent payments|last \d+ transactions)\b/.test(t))return {type:'HISTORY'};
  return {type:'UNKNOWN'};
}
function sha256(str){
  const K=[],H=[];const pr=[];for(let n=2;pr.length<64;n++){let ok=true;for(const q of pr){if(q*q>n)break;if(n%q===0){ok=false;break;}}if(ok)pr.push(n);}
  const fr=x=>Math.floor((x-Math.floor(x))*4294967296);
  for(let i=0;i<64;i++){K.push(fr(Math.cbrt(pr[i])));if(i<8)H.push(fr(Math.sqrt(pr[i])));}
  const b=new TextEncoder().encode(str);const l=b.length;const n=((l+9+63)>>6)<<6;const m=new Uint8Array(n);m.set(b);m[l]=0x80;
  const dv=new DataView(m.buffer);dv.setUint32(n-8,Math.floor(l*8/4294967296));dv.setUint32(n-4,(l*8)>>>0);
  let h=H.slice();const w=new Uint32Array(64);
  for(let i=0;i<n;i+=64){
    for(let t=0;t<16;t++)w[t]=dv.getUint32(i+t*4);
    for(let t=16;t<64;t++){const a=w[t-15],c=w[t-2];const s0=((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3);const s1=((c>>>17)|(c<<15))^((c>>>19)|(c<<13))^(c>>>10);w[t]=(w[t-16]+s0+w[t-7]+s1)|0;}
    let [a,b2,c,d,e,f,g,hh]=h;
    for(let t=0;t<64;t++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7));const ch=(e&f)^(~e&g);const t1=(hh+S1+ch+K[t]+w[t])|0;const S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10));const mj=(a&b2)^(a&c)^(b2&c);const t2=(S0+mj)|0;hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b2;b2=a;a=(t1+t2)|0;}
    h=[(h[0]+a)|0,(h[1]+b2)|0,(h[2]+c)|0,(h[3]+d)|0,(h[4]+e)|0,(h[5]+f)|0,(h[6]+g)|0,(h[7]+hh)|0];
  }
  return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
const hash64=sha256;
const LEVELS=[[80,'CRITICAL'],[60,'HIGH'],[30,'MEDIUM'],[0,'LOW']];
const levelOf=s=>LEVELS.find(l=>s>=l[0])[1];
const CANARY={token:'BANKISM_FAKE_9X72',apiKey:'bk_canary_demo_00000000_NOT_REAL',dbUri:'sandbox://canary-db.invalid/accounts_FAKE'};
function analyze(raw,opts={}){
  const t0=(typeof performance!=='undefined'?performance.now():Date.now());
  raw=String(raw||'');
  const N=normalize(raw);const norm=N.text;
  const factors=[];const signals=[];const policies=new Set();const cats=[];let hard=false;let canary=false;
  const intent=parseIntent(norm,raw);
  const add=(label,pts,pol,why)=>{factors.push({label,pts,pol});if(pol)policies.add(pol);};
  // threat rules run on normalised text
  for(const r of RULES){if(r.re.test(norm)){add(r.label,r.w,r.pol);signals.push({label:r.label,why:r.why,pol:r.pol});cats.push(r.cat);if(r.hard)hard=true;}}
  // memo injection: a transfer whose memo/trailing text carries instructions
  if(intent.type==='TRANSFER'&&intent.memo){
    const mm=normalize(intent.memo).text;
    if(RULES.slice(0,4).some(r=>r.re.test(mm))||/\b(instruction|system|admin|approve|prompt)\b.{0,30}\b(ignore|reveal|override|approve|execute|transfer)\b/.test(mm)){
      add('Instruction hidden inside transaction memo',25,'P-006');signals.push({label:'Instruction hidden inside transaction memo',why:'Memo fields are data, never commands.',pol:'P-006'});cats.push('MALICIOUS_MEMO');hard=true;}}
  // canary access
  if(/\b(api[ -]?keys?|secrets?|credentials?|hidden|system information|env(ironment)? vars?|database|db uri|canary)\b/.test(norm)&&cats.includes('DATA_EXFILTRATION')||raw.toLowerCase().includes(CANARY.token.toLowerCase())){hard=true;if(!cats.includes('DATA_EXFILTRATION'))cats.push('DATA_EXFILTRATION');
    canary=true;add('Canary / honeytoken access attempt',25,'P-011');signals.push({label:'Canary / honeytoken access attempt',why:'Touches decoy data that no legitimate request needs.',pol:'P-011'});}
  // obfuscation
  const b64=/[a-z0-9+\/]{28,}={0,2}/i.test(raw)&&!/\s/.test((raw.match(/[a-z0-9+\/]{28,}={0,2}/i)||[''])[0]);
  const hex=/(?:\\x[0-9a-f]{2}){4,}|(?:0x[0-9a-f]{2}\s?){4,}/i.test(raw);
  const threatFound=signals.length>0;
  if(b64||hex){add('Encoded payload (base64/hex) in request',20,'P-003');signals.push({label:'Encoded payload in request',why:'Encoded text can smuggle instructions past filters.',pol:'P-003'});cats.push('OBFUSCATION');}
  else if(N.changed&&N.steps.some(s=>!/whitespace/.test(s))){
    if(threatFound){add('Obfuscation to evade detection',20,'P-003');signals.push({label:'Obfuscation to evade detection',why:'Input was disguised and became hostile only after normalization.',pol:'P-003'});cats.push('OBFUSCATION');}
    else{add('Unusual character encoding',8,'P-003');}
  }
  // transaction validation
  if(intent.type==='TRANSFER'){
    if(!intent.beneficiary&&!intent.unknownName){add('Missing beneficiary',12,'P-010');}
    else if(intent.unknownName){add('Unknown beneficiary',15,'P-008');}
    else if(intent.beneficiary.trust==='new'){add('Newly added beneficiary',10,'P-008');}
    if(intent.amount==null){add('Ambiguous or missing amount',12,'P-010');}
    else if(intent.amount>=50000){add('High transaction amount',20,'P-009');}
    else if(intent.amount>=10000){add('Elevated transaction amount',8,'P-009');}
    if(intent.amount>100000)add('Exceeds daily transfer limit',10,'P-009');
    if(threatFound){add('Mixed intent: transaction combined with injection',15,'P-012');signals.push({label:'Mixed intent: transfer + attack content',why:'A legitimate-looking action wraps a hostile instruction.',pol:'P-012'});}
  }
  if(intent.type==='UNKNOWN'&&!threatFound&&norm.length>0){add('Intent not recognised',10,null);}
  let score=Math.min(100,factors.reduce((a,f)=>a+f.pts,0));
  const hardFloor=hard&&score<82;
  if(hardFloor){score=82;}
  if(intent.type==='TRANSFER'&&(intent.amount==null||!intent.beneficiary)&&score<30&&!hard)score=30;
  const level=levelOf(score);
  const financial=intent.type==='TRANSFER';
  let verdict=level==='LOW'?'ALLOW':level==='MEDIUM'?'CHALLENGE':level==='HIGH'?'HOLD':'BLOCK';
  if(level==='CRITICAL'&&financial&&cats.includes('PRIVILEGE_ESCALATION'))verdict='HONEYPOT';
  if(intent.type==='TRANSFER'&&verdict==='ALLOW'&&(intent.amount==null||(!intent.beneficiary)))verdict='CHALLENGE';
  const cat=cats.length?(cats.length>1&&cats.includes('MALICIOUS_MEMO')?'MALICIOUS_MEMO':cats.includes('DATA_EXFILTRATION')&&!cats.includes('PROMPT_INJECTION')?'DATA_EXFILTRATION':cats.includes('PROMPT_INJECTION')?'PROMPT_INJECTION':cats[0]):
     (verdict==='ALLOW'?'NONE':intent.type==='TRANSFER'?'TRANSACTION_RISK':'UNCLASSIFIED');
  const pols=[...policies].sort();
  const bankingAllowed=verdict==='ALLOW'&&intent.type!=='UNKNOWN';
  const action={ALLOW:intent.type==='UNKNOWN'?'No banking action was requested, so nothing was executed.':'Request forwarded to the simulated banking API.',CHALLENGE:'Held until step-up verification (simulated OTP) is completed.',HOLD:'Queued for manual review. Nothing executed.',BLOCK:'Request terminated at the firewall. Nothing reached the banking API.',HONEYPOT:'Session diverted to an isolated sandbox with fake data. Real banking APIs untouched.'}[verdict];
  const why=signals.length?signals.map(s=>s.why).slice(0,2).join(' '):factors.length?'Transaction attributes raised the risk score above the clean threshold.':'No hostile patterns found and transaction attributes are within policy.';
  const reason=verdict==='ALLOW'?(intent.type==='TRANSFER'?'Intent, amount and trusted beneficiary verified. No injection signals detected.':'Read-only request with no hostile content.'):
     signals.length?'Request '+(cats.includes('PRIVILEGE_ESCALATION')?'claims elevated privileges':cats.includes('DATA_EXFILTRATION')?'tries to extract protected information':cats.includes('MALICIOUS_MEMO')?'hides instructions in a transaction field':'attempts to override system instructions')+(financial?' and requests a financial action':'')+'.':
     'Transaction attributes require additional assurance before execution.';
  const ms=Math.max(9,Math.round((typeof performance!=='undefined'?performance.now():Date.now())-t0)+14+Math.min(60,norm.length%37+signals.length*6));
  const ts=opts.ts||new Date().toISOString();
  const rh=hash64('req:'+raw),dh=hash64(['dec',rh,verdict,score,cat,pols.join(',')].join('|'));
  const idn=parseInt(rh.slice(0,6),16)%90000+10000;
  return {id:'INC-'+idn,ts,raw,sanitized:sanitize(N.text&&N.changed?raw:raw),normalized:norm,normSteps:N.steps,intent,signals,factors,
    score,level,verdict,category:cat,policies:pols,reason,why,action,bankingAllowed,canary,detectMs:ms,hardFloor,
    requestHash:rh,decisionHash:dh};
}
if(typeof module!=='undefined')module.exports={sha256,analyze,normalize,BENEFICIARIES,POLICIES,CANARY,levelOf,hash64};
