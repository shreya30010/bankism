/* ===== Simulated ledger + single execution gate (pure, testable) ===== */
const DAILY_LIMIT=100000;
function createLedger(init){
  const st={balance:init.balance,daily:0,locked:false,executed:new Set(),history:init.history.slice(),escapes:0,rejections:[],seq:0};
  const rej=(code,msg)=>{st.rejections.unshift({code,msg,ts:Date.now()});return {ok:false,code,msg};};
  function execute(r,o){
    o=o||{};
    if(o.origin==='sandbox'){st.escapes++;return rej('SANDBOX_ORIGIN','Sandbox sessions can never reach the banking gate.');}
    if(st.locked)return rej('LOCKED','Privileged actions are locked after a canary incident.');
    if(!r||!r.intent||r.intent.type!=='TRANSFER')return rej('NOT_A_TRANSFER','Only transfers pass through the execution gate.');
    const re=analyze(r.raw);                               // the gate re-derives the decision itself; it never trusts the caller's object
    if(re.decisionHash!==r.decisionHash||re.verdict!==r.verdict)return rej('TAMPERED_DECISION','Decision does not match a fresh evaluation of the request.');
    const ok=r.verdict==='ALLOW'||(r.verdict==='CHALLENGE'&&o.verified===true&&r.signals.length===0);
    if(!ok)return rej('VERDICT','Verdict '+r.verdict+' does not permit execution.');
    const a=r.intent.amount;
    if(!r.intent.beneficiary||a==null||!(a>0))return rej('INCOMPLETE','Beneficiary or amount missing.');
    const key=r.ts+':'+r.requestHash;
    if(st.executed.has(key))return rej('DUPLICATE','This decision was already executed (replay rejected).');
    if(a>st.balance)return rej('FUNDS','Insufficient simulated funds.');
    if(st.daily+a>DAILY_LIMIT)return rej('DAILY_LIMIT','Daily simulated transfer limit would be exceeded.');
    st.executed.add(key);st.balance-=a;st.daily+=a;
    const tx={id:'t'+(++st.seq)+'_'+Date.now(),ts:Date.now(),to:r.intent.beneficiary.name,amt:a,memo:r.intent.memo||'',status:'COMPLETED'};
    st.history.unshift(tx);return {ok:true,tx};
  }
  function addBlocked(r){const a=r.intent&&r.intent.amount||0;const to=r.intent&&(r.intent.beneficiary?r.intent.beneficiary.name:(r.intent.unknownName||'—'))||'—';
    st.history.unshift({id:'t'+(++st.seq)+'_'+Date.now(),ts:Date.now(),to,amt:a,memo:'',status:'BLOCKED'});}
  return {st,execute,addBlocked,lock(){st.locked=true;},unlock(){st.locked=false;},snapshot(){return {balance:st.balance,daily:st.daily,locked:st.locked,history:st.history.slice(),escapes:st.escapes,rejections:st.rejections.slice(0,20)};}};
}
