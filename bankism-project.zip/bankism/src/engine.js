/* ===== BANKISM deterministic firewall engine (local simulation: regex rules + arithmetic, NO ML/LLM) ===== */
const ENGINE_VERSION='2.0.0';
const BENEFICIARIES=[
 {id:'b1',name:'Rahul',acct:'XXXX-4821',trust:'trusted',note:'Added 14 months ago'},
 {id:'b2',name:'Priya',acct:'XXXX-7710',trust:'trusted',note:'Added 9 months ago'},
 {id:'b3',name:'Ananya',acct:'XXXX-3095',trust:'trusted',note:'Added 5 months ago'},
 {id:'b4',name:'Vikram',acct:'XXXX-5532',trust:'new',note:'Added 2 days ago'},
 {id:'b5',name:'Meera',acct:'XXXX-9164',trust:'trusted',note:'Added 22 months ago'}];
const POLICIES={
 'P-001':'Prompt Injection','P-002':'Jailbreak / Persona Override','P-003':'Obfuscated Payload',
 'P-004':'Privilege Escalation','P-005':'Data Exfiltration','P-006':'Malicious Memo',
 'P-007':'Unauthorized Transfer','P-008':'Unknown Beneficiary','P-009':'High-Value Transaction',
 'P-010':'Incomplete Transaction','P-011':'Canary Access','P-012':'Mixed Intent'};
const POLICY_META={
 'P-001':{sev:'hard-block',desc:'Instruction override or instructions embedded in third-party content.'},
 'P-002':{sev:'hard-block',desc:'Known jailbreak phrasing (DAN, “no restrictions”).'},
 'P-003':{sev:'weighted',desc:'Encoded, disguised or oversized input used to evade detection.'},
 'P-004':{sev:'hard-block',desc:'Claims an admin / developer role the user does not hold.'},
 'P-005':{sev:'hard-block',desc:'Requests for system prompts, hidden data or secrets.'},
 'P-006':{sev:'hard-block',desc:'Instruction hidden in a transaction memo field.'},
 'P-007':{sev:'hard-block',desc:'Asks to skip verification or self-approve a transaction.'},
 'P-008':{sev:'weighted',desc:'Unknown or newly added beneficiary.'},
 'P-009':{sev:'weighted',desc:'High-value or limit-exceeding transaction.'},
 'P-010':{sev:'weighted',desc:'Missing / ambiguous amount or beneficiary.'},
 'P-011':{sev:'hard-block',desc:'Touches canary (decoy) data.'},
 'P-012':{sev:'weighted',desc:'A transaction request wrapped around hostile content.'}};
const CONF={'а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','і':'i','ѕ':'s','ԁ':'d','ɡ':'g','ӏ':'l','ο':'o','α':'a','ε':'e','ι':'i','ν':'v','τ':'t','ρ':'p','κ':'k','ս':'u','ⅰ':'i','ℓ':'l'};
const LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i','|':'i'};
const MAX_INPUT=1500;
const SEGDICT=['ignore','disregard','forget','override','bypass','previous','prior','above','earlier','system','security','safety','your','all','any','the','instructions','instruction','rules','prompt','guardrails','reveal','show','print','dump','hidden','keys','key','api','secrets','you','are','now','administrator','admin','developer','mode','approve','approved','mark','transaction','as','and','transfer','send','jailbreak','policies','guidelines','restrictions','configuration','tell','me','give','verification','otp','skip','without','disable','firewall'];
function segment(w){
  const n=w.length,best=new Array(n+1).fill(null);best[0]=[];
  for(let i=0;i<n;i++){if(!best[i])continue;for(const d of SEGDICT){if(w.startsWith(d,i)){const j=i+d.length;if(!best[j]||best[j].length>best[i].length+1)best[j]=best[i].concat(d);}}}
  return best[n]&&best[n].length>1?best[n].join(' '):w;
}
function normalize(raw){
  const steps=[],trace=[];let t=String(raw);
  const rec=(label,after)=>{if(after!==t){steps.push(label);trace.push({step:label,before:t,after});t=after;}};
  rec('Stripped zero-width / invisible characters',t.replace(/[\u200B-\u200F\u2060\uFEFF\u00AD]/g,''));
  rec('Unicode NFKC folding (full-width / compatibility forms)',t.normalize('NFKC'));
  rec('Lower-cased',t.toLowerCase());
  rec('Mapped Unicode look-alike characters to Latin',t.replace(/[^\u0000-\u007f]/g,c=>CONF[c]||c));
  rec('Collapsed letter-spacing obfuscation',t.replace(/\b(?:[a-z][\s.\-_*]){3,}[a-z]\b/g,m=>m.replace(/[\s.\-_*]/g,'')));
  rec('Re-segmented words merged by letter-spacing',t.replace(/\b[a-z]{12,}\b/g,w=>segment(w)));
  rec('Decoded leetspeak substitutions',t.replace(/\b[a-z0-9@$!|]{4,}\b/g,w=>{
    if(!/[a-z]/.test(w)||!/[01345 7@$!|]/.test(w))return w;
    if(/^\d+$/.test(w)||(/\d/.test(w)&&/^[a-z]{0,3}\d{2,}/.test(w)))return w;
    return w.replace(/[013457@$!|]/g,c=>LEET[c]);}));
  rec('Collapsed irregular whitespace',t.replace(/\s+/g,' ').trim());
  const meaningful=steps.filter(s=>!/Lower-cased|whitespace/.test(s));
  return {text:t,steps,trace,changed:meaningful.length>0};
}
function sanitize(raw){
  return String(raw).replace(/[\u200B-\u200F\u2060\uFEFF\u00AD]/g,'')
   .replace(/\b\d{9,18}\b/g,'[ACCT]').replace(/\b[\w.+-]+@[\w-]+\.[\w.]+\b/g,'[EMAIL]')
   .replace(/\b(?:\+?91[\s-]?)?[6-9]\d{9}\b/g,'[PHONE]').slice(0,240);
}
const RULES=[
 {id:'R-OVERRIDE',cat:'PROMPT_INJECTION',pol:'P-001',w:35,label:'System instruction override',hard:true,
  why:'Attempts to make the model discard its safety rules.',re:/\b(ignore|disregard|forget|override|bypass)\b.{0,25}\b(previous|prior|above|earlier|system|security|safety|your|all|any|the)\b.{0,25}\b(instruction|instructions|rules|prompt|guardrails?|polic(?:y|ies)|guidelines|directives?|restrictions)\b/},
 {id:'R-ROLE',cat:'PRIVILEGE_ESCALATION',pol:'P-004',w:30,label:'Role manipulation / privilege escalation',hard:true,
  why:'Claims an admin or privileged identity the user does not hold.',
  re:/\b(?:you are now|act as|pretend (?:to be|you are)|behave as)\s+(?:the\s+|a\s+|an\s+|your\s+)?(?:bank\s+|system\s+|root\s+|super\s?)?(?:admin|administrator|root|superuser|developer|operator|manager)\b|\b(?:i am|i'm|this is)\s+(?:the\s+|your\s+)?(?:(?:bank|system|root|super)\s?)?(?:admin|administrator|root|superuser)\b|\bdeveloper mode\b|\bsudo\b|\badmin(?:istrator)? (?:override|access|mode)\b/},
 {id:'R-JAILBREAK',cat:'JAILBREAK',pol:'P-002',w:35,label:'Jailbreak pattern',hard:true,
  why:'Known jailbreak phrasing used to remove model restrictions.',re:/\bjail ?break\b|\bdo anything now\b|\bdan mode\b|\bno (restrictions|limits|filters)\b|\bwithout (any )?(restrictions|limits|filters)\b|\bunrestricted mode\b/},
 {id:'R-EXFIL',cat:'DATA_EXFILTRATION',pol:'P-005',w:40,label:'Hidden information / system prompt request',hard:true,
  why:'Tries to extract confidential configuration or secrets.',
  re:/\b(?:reveal|show|print|dump|leak|expose|display|output|tell me|give me|share|repeat|list)\b.{0,40}\b(?:system prompt|system information|(?:your|the|hidden|initial|original|internal|secret|system) (?:instructions|rules|prompt|configuration|config)|hidden (?:api |system )?(?:keys?|secrets?|credentials?|data|information|files?|configuration|config)|api[ -]?keys?|secrets?|(?:admin|root|database|system|other users'?) passwords?|credentials?|(?:access|auth|session|bearer) tokens?|env(?:ironment)? (?:vars?|variables)|(?:training|source) (?:data|code))\b|\bwhat (?:are|is) your (?:system )?(?:prompt|instructions)\b|\brepeat (?:everything|the text) above\b|\bhidden configuration\b/},
 {id:'R-UNAUTH',cat:'UNAUTHORIZED_ACTION',pol:'P-007',w:25,label:'Unauthorized privileged action',hard:true,
  why:'Requests approval, verification or limits to be skipped.',re:/\bmark (it |this |the transaction |transaction )?(as )?(approved|verified|safe|completed)\b|\b(skip|bypass|disable|turn off|waive)\b.{0,20}\b(verification|otp|2fa|mfa|approval|firewall|security|limits?|checks?)\b|\bwithout (any )?(approval|verification|otp|authori[sz]ation)\b|\bauto[- ]?approve\b|\bapprove (it )?yourself\b/},
 {id:'R-INDIRECT',cat:'INDIRECT_INJECTION',pol:'P-001',w:35,label:'Indirect injection: instructions embedded in third-party content',hard:true,
  why:'Content pasted from an invoice, email or page is trying to command the assistant.',
  re:/\b(?:note|message|instructions?|attention|important)\s+(?:to|for)\s+(?:the\s+)?(?:ai|assistant|bot|agent|model|llm)\b|\bif you are (?:an? )?(?:ai|assistant|llm|language model|bot)\b|\[\s*(?:system|admin|assistant|developer)\s*\]|<\/?\s*(?:system|admin|instructions?)\s*>|#{2,}\s*(?:system|new instructions?)|\bbegin (?:system|hidden|new) (?:prompt|instructions?)\b|\b(?:invoice|email|document|pdf|attachment|webpage|web page|statement)\b[^.]{0,80}\b(?:says?|states?|reads?|instructs?|contains?)\b[^.]{0,40}\b(?:ignore|override|bypass|approve (?:all|every|without)|skip verification)\b/},
 {id:'R-ML-OVERRIDE',cat:'PROMPT_INJECTION',pol:'P-001',w:35,label:'Multilingual instruction override (ES/FR/DE/HI/Hinglish patterns)',hard:true,
  why:'Instruction override phrased in another language.',
  re:/ignora(?:r)?\s+(?:todas\s+)?(?:las\s+)?(?:instrucciones|reglas)|olvida\s+(?:todas\s+)?(?:las\s+)?instrucciones|ignore(?:z|r)?\s+(?:toutes\s+)?(?:les\s+)?(?:instructions|r[eè]gles)|ignoriere?\s+(?:alle\s+)?(?:vorherigen\s+)?(?:anweisungen|regeln)|(?:पिछले|सभी|पहले|पुराने)\s*(?:सभी\s*)?(?:निर्देश|निर्देशों|नियम|नियमों)[^.]{0,20}अनदेखा|(?:pichle|purane|sabhi|saare)\s+(?:sabhi\s+)?(?:instructions?|niyam|rules?)\s+(?:ko\s+)?(?:ignore|bhool|andekha)/},
 {id:'R-ML-EXFIL',cat:'DATA_EXFILTRATION',pol:'P-005',w:40,label:'Multilingual secret / prompt extraction (ES/FR)',hard:true,
  why:'Extraction request phrased in another language.',
  re:/(?:muestra|revela|dime|imprime)\b.{0,30}(?:prompt del sistema|claves?(?: de)? api|contrase[ñn]as?|instrucciones del sistema)|(?:montre|r[ée]v[eè]le|affiche)\b.{0,30}(?:prompt syst[eè]me|cl[ée]s? api|mots? de passe)/}
];
const RULES_INFO=RULES.map(r=>({id:r.id,pol:r.pol,label:r.label,hard:r.hard,w:r.w,cat:r.cat}));
const MEMO_RULE_IDS=['R-OVERRIDE','R-ROLE','R-JAILBREAK','R-EXFIL','R-UNAUTH','R-ML-OVERRIDE','R-INDIRECT'];
const UNIT={k:1e3,l:1e5,lakh:1e5,lakhs:1e5,cr:1e7,crore:1e7,crores:1e7};
function parseAmount(s){
  let m=s.match(/(?:₹|\brs\.?|\binr\b|\$|\busd\b)\s*(-?\d[\d,]*(?:\.\d+)?)\s*(k|lakhs?|crores?|cr|l)?(?![a-z])/i);
  if(m){return parseFloat(m[1].replace(/,/g,''))*(UNIT[(m[2]||'').toLowerCase()]||1);}
  m=s.match(/\b(\d[\d,]*(?:\.\d+)?)\s*(k|lakhs?|crores?|cr|rupees|rs|inr)\b/i);
  if(m){return parseFloat(m[1].replace(/,/g,''))*(UNIT[m[2].toLowerCase()]||1);}
  m=s.match(/\b(?:transfer|send|pay|wire)\b\s+(\d[\d,]*(?:\.\d+)?)\b/i);
  if(m)return parseFloat(m[1].replace(/,/g,''));
  return null;
}
function parseIntent(norm,raw){
  const t=norm;
  const tv=t.replace(/\b(?:transfer|payment|send|pay)\s+(?:limits?|fees?|charges?|history|polic(?:y|ies)|rules?|options?|status|receipts?)\b/g,' ').replace(/\b(?:the|my|a|your|daily)\s+transfers?\b/g,' ');
  const isQuestion=/^(?:what|how|why|when|where|explain)\b/.test(t);
  if(!isQuestion&&/\b(transfer|send|pay|wire|remit|move)\b/.test(tv)){
    let amount=parseAmount(String(raw).normalize('NFKC'));if(amount==null)amount=parseAmount(t);
    let amountInvalid=false;if(amount!=null&&(!(amount>0)||!isFinite(amount))){amount=null;amountInvalid=true;}
    const named=BENEFICIARIES.filter(b=>new RegExp('\\b'+b.name.toLowerCase()+'\\b').test(t));
    let ben=named.length===1?named[0]:null,unknown=null;
    if(!named.length){const m=t.match(/\bto\s+(?:account\s+)?([a-z][a-z]{2,15})\b/);const stop=['the','my','me','this','that','account','him','her','them','another','someone','x','admin','administrator'];if(m&&!stop.includes(m[1]))unknown=m[1];}
    const memoM=String(raw).match(/(?:memo|note|reference|remark|message)\s*[:=]\s*["“']?([^"”'\n]+)|\bfor\s+([^.\n]{3,})$/i);
    return {type:'TRANSFER',amount,amountInvalid,beneficiary:ben,multi:named.length>1,unknownName:unknown,memo:memoM?(memoM[1]||memoM[2]||'').trim():null};
  }
  if(/\b(balance|how much (money )?do i have)\b/.test(t))return {type:'BALANCE'};
  if(/\b(history|statement|transactions|recent payments|last \d+ transactions)\b/.test(t))return {type:'HISTORY'};
  return {type:'UNKNOWN'};
}
function sha256(str){
  const K=[],H=[];const pr=[];for(let n=2;pr.length<64;n++){let ok=true;for(const q of pr){if(q*q>n)break;if(n%q===0){ok=false;break;}}if(ok)pr.push(n);}
  const fr=x=>Math.floor((x-Math.floor(x))*4294967296);
  for(let i=0;i<64;i++){K.push(fr(Math.cbrt(pr[i])));if(i<8)H.push(fr(Math.sqrt(pr[i])));}
  const b=new TextEncoder().encode(str);const l=b.length;const n=((l+9+63)>>6)<<6;const m=new Uint8Array(n);m.set(b);m[l]=0x80;
  const dv=new DataView(m.buffer);dv.setUint32(n-8,Math.floor(l*8/4294967296));dv.setUint32(n-4,(l*8)>>>0);
  let h=H.slice();const w=new Uint32Array(64);
  for(let i=0;i<n;i+=64){
    for(let t=0;t<16;t++)w[t]=dv.getUint32(i+t*4);
    for(let t=16;t<64;t++){const a=w[t-15],c=w[t-2];const s0=((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3);const s1=((c>>>17)|(c<<15))^((c>>>19)|(c<<13))^(c>>>10);w[t]=(w[t-16]+s0+w[t-7]+s1)|0;}
    let [a,b2,c,d,e,f,g,hh]=h;
    for(let t=0;t<64;t++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7));const ch=(e&f)^(~e&g);const t1=(hh+S1+ch+K[t]+w[t])|0;const S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10));const mj=(a&b2)^(a&c)^(b2&c);const t2=(S0+mj)|0;hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b2;b2=a;a=(t1+t2)|0;}
    h=[(h[0]+a)|0,(h[1]+b2)|0,(h[2]+c)|0,(h[3]+d)|0,(h[4]+e)|0,(h[5]+f)|0,(h[6]+g)|0,(h[7]+hh)|0];
  }
  return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
const hash64=sha256;
const LEVELS=[[80,'CRITICAL'],[60,'HIGH'],[30,'MEDIUM'],[0,'LOW']];
const levelOf=s=>LEVELS.find(l=>s>=l[0])[1];
const CANARY={token:'BANKISM_FAKE_9X72',apiKey:'bk_canary_demo_00000000_NOT_REAL',dbUri:'sandbox://canary-db.invalid/accounts_FAKE'};
const RULESET_ID=sha256(RULES.map(r=>r.id+':'+r.re.source).join('|')).slice(0,12);
function decodeB64Candidates(raw){
  const out=[];const re=/[A-Za-z0-9+\/]{20,}={0,2}/g;let m;
  while((m=re.exec(raw))&&out.length<3){
    try{if(typeof atob!=='function')break;const bin=atob(m[0].padEnd(Math.ceil(m[0].length/4)*4,'='));
      let ok=0;for(let i=0;i<bin.length;i++){const c=bin.charCodeAt(i);if((c>=32&&c<127)||c===10)ok++;}
      if(bin.length>=8&&ok/bin.length>=0.92)out.push(bin);}catch(e){}}
  return out;
}
function _analyze(raw0,opts){
  const pt=(typeof performance!=='undefined'?performance:Date);const t0=pt.now();
  const raw=(raw0==null?'':String(raw0));const work=raw.slice(0,MAX_INPUT);const over=raw.length>MAX_INPUT;
  const N=normalize(work);const norm=N.text;
  const factors=[],signals=[],policies=new Set(),cats=[],ruleHits=[];let hard=false;let canary=false;const hardWhy=[];
  const intent=parseIntent(norm,work);
  const add=(label,pts,pol,ruleId)=>{factors.push({label,pts,pol,rule:ruleId||null});if(pol)policies.add(pol);};
  // base64 deep scan: decode printable payloads and scan them as well
  const decoded=decodeB64Candidates(work);let scan=norm;
  for(const d of decoded){scan+=' '+normalize(d).text;}
  for(const r of RULES){const m=scan.match(r.re);if(m){add(r.label,r.w,r.pol,r.id);signals.push({label:r.label,why:r.why,pol:r.pol,rule:r.id,match:trunc0(m[0],60)});ruleHits.push({id:r.id,pol:r.pol,weight:r.w,hard:r.hard,match:trunc0(m[0],60)});cats.push(r.cat);if(r.hard){hard=true;hardWhy.push(r.pol+' '+r.label);}}}
  if(intent.type==='TRANSFER'&&intent.memo){
    const mm=normalize(intent.memo).text;
    if(RULES.some(r=>MEMO_RULE_IDS.includes(r.id)&&r.re.test(mm))){
      add('Instruction hidden inside transaction memo',25,'P-006','R-MEMO');signals.push({label:'Instruction hidden inside transaction memo',why:'Memo fields are data, never commands.',pol:'P-006',rule:'R-MEMO',match:trunc0(mm,60)});ruleHits.push({id:'R-MEMO',pol:'P-006',weight:25,hard:true,match:trunc0(mm,60)});cats.push('MALICIOUS_MEMO');hard=true;hardWhy.push('P-006 Instruction hidden inside transaction memo');}}
  if((/\b(api[ -]?keys?|secrets?|credentials?|hidden|system information|env(ironment)? vars?|database|db uri|canary)\b/.test(norm)&&cats.includes('DATA_EXFILTRATION'))||raw.toLowerCase().includes(CANARY.token.toLowerCase())){
    canary=true;hard=true;hardWhy.push('P-011 Canary / honeytoken access attempt');if(!cats.includes('DATA_EXFILTRATION'))cats.push('DATA_EXFILTRATION');
    add('Canary / honeytoken access attempt',25,'P-011','R-CANARY');signals.push({label:'Canary / honeytoken access attempt',why:'Touches decoy data that no legitimate request needs.',pol:'P-011',rule:'R-CANARY',match:'canary reference'});ruleHits.push({id:'R-CANARY',pol:'P-011',weight:25,hard:true,match:'canary reference'});}
  const threatFound=signals.length>0;
  if(decoded.length){
    if(threatFound){add('Encoded (base64) payload hiding instructions',20,'P-003','R-B64');signals.push({label:'Encoded payload in request',why:'Encoded text can smuggle instructions past filters; it was decoded and re-scanned.',pol:'P-003',rule:'R-B64',match:'base64 → '+trunc0(decoded[0],40)});ruleHits.push({id:'R-B64',pol:'P-003',weight:20,hard:false,match:'base64'});cats.push('OBFUSCATION');}
    else{add('Encoded (base64) text in a banking request',30,'P-003','R-B64');signals.push({label:'Encoded text in request',why:'Banking requests are plain language; decoded content was benign but unexpected.',pol:'P-003',rule:'R-B64',match:'base64'});ruleHits.push({id:'R-B64',pol:'P-003',weight:30,hard:false,match:'base64'});cats.push('OBFUSCATION');}
  }else if(N.changed&&threatFound){add('Obfuscation to evade detection',20,'P-003','R-OBF');signals.push({label:'Obfuscation to evade detection',why:'Input was disguised and became hostile only after normalization.',pol:'P-003',rule:'R-OBF',match:N.steps.filter(s=>!/Lower-cased|whitespace/.test(s))[0]});ruleHits.push({id:'R-OBF',pol:'P-003',weight:20,hard:false,match:'normalization changed input'});cats.push('OBFUSCATION');}
  else if(N.changed){add('Unusual character encoding',8,'P-003','R-OBF');}
  if(over){add('Oversized input (padding / context-stuffing)',30,'P-003','R-SIZE');signals.push({label:'Oversized input',why:'Requests above '+MAX_INPUT+' characters are rejected; padding can bury instructions.',pol:'P-003',rule:'R-SIZE',match:raw.length+' chars'});ruleHits.push({id:'R-SIZE',pol:'P-003',weight:30,hard:true,match:raw.length+' chars'});cats.push('OBFUSCATION');hard=true;hardWhy.push('P-003 Oversized input');}
  const sig0=signals.length>0;
  if(intent.type==='TRANSFER'){
    if(intent.multi)add('Multiple beneficiaries named (ambiguous)',12,'P-010','R-TX');
    else if(!intent.beneficiary&&!intent.unknownName)add('Missing beneficiary',12,'P-010','R-TX');
    else if(intent.unknownName)add('Unknown beneficiary',15,'P-008','R-TX');
    else if(intent.beneficiary.trust==='new')add('Newly added beneficiary',10,'P-008','R-TX');
    if(intent.amountInvalid)add('Invalid amount (zero or negative)',12,'P-010','R-TX');
    else if(intent.amount==null)add('Ambiguous or missing amount',12,'P-010','R-TX');
    else if(intent.amount>=50000)add('High transaction amount',20,'P-009','R-TX');
    else if(intent.amount>=10000)add('Elevated transaction amount',8,'P-009','R-TX');
    if(intent.amount>100000)add('Exceeds daily transfer limit',10,'P-009','R-TX');
    if(sig0){add('Mixed intent: transaction combined with injection',15,'P-012','R-MIX');signals.push({label:'Mixed intent: transfer + attack content',why:'A legitimate-looking action wraps a hostile instruction.',pol:'P-012',rule:'R-MIX',match:'transfer + threat'});ruleHits.push({id:'R-MIX',pol:'P-012',weight:15,hard:false,match:'transfer + threat'});}
  }
  if(intent.type==='UNKNOWN'&&!sig0&&norm.length>0)add('Intent not recognised',10,null,'R-INTENT');
  const rawTotal=factors.reduce((a,f)=>a+f.pts,0);let score=Math.min(100,rawTotal);const path=['Σ weighted factors = '+rawTotal+(rawTotal>100?' (capped at 100)':'')];
  let floor=null;
  if(hard&&score<82){floor={from:score,to:82};score=82;path.push('Hard-block policy present ('+hardWhy.join('; ')+') → score floor raised '+floor.from+' → 82');}
  else if(hard)path.push('Hard-block policy present ('+hardWhy.join('; ')+'); score already ≥ 82');
  const incomplete=intent.type==='TRANSFER'&&(intent.amount==null||!intent.beneficiary);
  if(incomplete&&score<30&&!hard){path.push('Incomplete transfer → minimum MEDIUM (30)');score=30;}
  const level=levelOf(score);path.push('Score '+score+' → level '+level);
  const financial=intent.type==='TRANSFER';
  let verdict=level==='LOW'?'ALLOW':level==='MEDIUM'?'CHALLENGE':level==='HIGH'?'HOLD':'BLOCK';
  path.push('Level '+level+' → '+verdict);
  if(level==='CRITICAL'&&financial&&cats.includes('PRIVILEGE_ESCALATION')){verdict='HONEYPOT';path.push('Critical + financial intent + privilege escalation → divert to HONEYPOT');}
  if(financial&&verdict==='ALLOW'&&incomplete){verdict='CHALLENGE';path.push('ALLOW downgraded: transfer is incomplete → CHALLENGE');}
  if(verdict==='ALLOW'&&signals.length){verdict='CHALLENGE';path.push('Invariant: any detected signal prevents ALLOW → CHALLENGE');}
  const pols=[...policies].sort();
  const bankingAllowed=verdict==='ALLOW'&&intent.type!=='UNKNOWN';
  const pri=['MALICIOUS_MEMO','DATA_EXFILTRATION_ONLY','INDIRECT_INJECTION'];
  let cat;
  if(!cats.length)cat=verdict==='ALLOW'?'NONE':financial?'TRANSACTION_RISK':'UNCLASSIFIED';
  else if(cats.length>1&&cats.includes('MALICIOUS_MEMO'))cat='MALICIOUS_MEMO';
  else if(cats.includes('DATA_EXFILTRATION')&&!cats.includes('PROMPT_INJECTION')&&!cats.includes('INDIRECT_INJECTION'))cat='DATA_EXFILTRATION';
  else if(cats.includes('PROMPT_INJECTION'))cat='PROMPT_INJECTION';
  else if(cats.includes('INDIRECT_INJECTION'))cat='INDIRECT_INJECTION';
  else cat=cats[0];
  const action={ALLOW:intent.type==='UNKNOWN'?'No banking action was requested, so nothing was executed.':'Request forwarded to the simulated banking API.',CHALLENGE:'Held until step-up verification (simulated OTP) is completed.',HOLD:'Queued for manual review. Nothing executed.',BLOCK:'Request terminated at the firewall. Nothing reached the banking API.',HONEYPOT:'Session diverted to an isolated sandbox with fake data. Real banking APIs untouched.'}[verdict];
  const why=signals.length?signals.map(s=>s.why).slice(0,2).join(' '):factors.length?'Transaction attributes raised the risk score above the clean threshold.':'No hostile patterns found and transaction attributes are within policy.';
  const reason=verdict==='ALLOW'?(intent.type==='TRANSFER'?'Intent, amount and trusted beneficiary verified. No injection signals detected.':'Read-only request with no hostile content.'):
     signals.length?'Request '+(cats.includes('PRIVILEGE_ESCALATION')?'claims elevated privileges':cats.includes('DATA_EXFILTRATION')?'tries to extract protected information':cats.includes('MALICIOUS_MEMO')?'hides instructions in a transaction field':cats.includes('INDIRECT_INJECTION')?'carries instructions embedded in third-party content':cats.includes('OBFUSCATION')&&!cats.includes('PROMPT_INJECTION')?'uses encoding or padding to hide its content':'attempts to override system instructions')+(financial?' and requests a financial action':'')+'.':
     'Transaction attributes require additional assurance before execution.';
  const ts=opts.ts||new Date().toISOString();
  const rh=sha256('req:'+raw.slice(0,5000)),dh=sha256(['dec',rh,verdict,score,cat,pols.join(',')].join('|'));
  const idn=parseInt(rh.slice(0,6),16)%90000+10000;
  const detectMs=+(pt.now()-t0).toFixed(2);
  return {id:'INC-'+idn,ts,raw,sanitized:sanitize(raw),normalized:norm,normSteps:N.steps,trace:N.trace,decoded,intent,signals,factors,
    score,level,verdict,category:cat,policies:pols,reason,why,action,bankingAllowed,canary,detectMs,hardFloor:!!floor,
    requestHash:rh,decisionHash:dh,engineVersion:ENGINE_VERSION,
    explain:{method:'Deterministic rule engine (regex patterns + arithmetic). No machine-learning or LLM inference is used.',rules:ruleHits,rawTotal,floor,hard,hardWhy,path,ruleset:RULESET_ID}};
}
function trunc0(s,n){s=String(s);return s.length>n?s.slice(0,n-1)+'…':s;}
function failClosed(raw,opts,err){
  let raw0='';try{raw0=raw==null?'':String(raw);}catch(e2){raw0='[unprintable input]';}const ts=(opts&&opts.ts)||new Date().toISOString();
  const rh=sha256('req:'+raw0.slice(0,5000)),dh=sha256(['dec',rh,'BLOCK',100,'ENGINE_ERROR',''].join('|'));
  return {id:'INC-'+(parseInt(rh.slice(0,6),16)%90000+10000),ts,raw:raw0,sanitized:'[unavailable]',normalized:'',normSteps:[],trace:[],decoded:[],intent:{type:'UNKNOWN'},
    signals:[{label:'Engine fault — failing closed',why:'An internal error occurred, so the request is denied by default.',pol:null,rule:'R-FAILCLOSED',match:(function(){try{return String(err&&err.message||err).slice(0,80);}catch(e3){return 'unprintable error';}})()}],factors:[],
    score:100,level:'CRITICAL',verdict:'BLOCK',category:'ENGINE_ERROR',policies:[],reason:'The firewall hit an internal error and failed closed. Nothing was executed.',why:'Fail-closed design: faults deny, never allow.',action:'Request terminated at the firewall. Nothing reached the banking API.',
    bankingAllowed:false,canary:false,detectMs:0,hardFloor:false,requestHash:rh,decisionHash:dh,engineVersion:ENGINE_VERSION,
    explain:{method:'Fail-closed fallback.',rules:[],rawTotal:0,floor:null,hard:true,hardWhy:['engine fault'],path:['Engine fault → BLOCK (fail-closed)'],ruleset:RULESET_ID}};
}
function analyze(raw,opts){opts=opts||{};try{return _analyze(raw,opts);}catch(e){return failClosed(raw,opts,e);}}
/* ===== receipts & hash chain ===== */
const GENESIS='0'.repeat(64);
const VLABEL={ALLOW:'ALLOWED',CHALLENGE:'CHALLENGE',HOLD:'HELD',BLOCK:'BLOCKED',HONEYPOT:'HONEYPOT'};
const VUNLABEL=Object.fromEntries(Object.entries(VLABEL).map(([k,v])=>[v,k]));
function canon(o){if(Array.isArray(o))return '['+o.map(canon).join(',')+']';if(o&&typeof o==='object')return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canon(o[k])).join(',')+'}';return JSON.stringify(o);}
function buildReceipt(e,prevHash){
  const body={receipt_type:'DEMO_AUDIT_RECORD',engine_version:e.engineVersion||ENGINE_VERSION,incident_id:e.id,verdict:VLABEL[e.verdict],risk_level:e.level,risk_score:e.score,threat_category:e.category,
    policies_triggered:e.policies,timestamp:e.ts,request_hash:'sha256:'+e.requestHash,decision_hash:'sha256:'+e.decisionHash,previous_receipt_hash:prevHash||GENESIS,pii_in_receipt:false};
  return {...body,receipt_hash:'sha256:'+sha256(canon(body))};
}
function verifyChain(chain,o){
  o=o||{};const results=[];let allOk=true;
  chain.forEach((r,i)=>{
    const problems=[];const {receipt_hash,...body}=r;
    if('sha256:'+sha256(canon(body))!==receipt_hash)problems.push('receipt_hash does not match record contents');
    const rh=String(r.request_hash||'').replace('sha256:','');const v=VUNLABEL[r.verdict];
    const dh='sha256:'+sha256(['dec',rh,v,r.risk_score,r.threat_category,(r.policies_triggered||[]).join(',')].join('|'));
    if(dh!==r.decision_hash)problems.push('decision_hash does not match verdict / score / category / policies');
    if(i>0&&r.previous_receipt_hash!==chain[i-1].receipt_hash)problems.push('previous_receipt_hash does not match the preceding record (record altered, removed or reordered)');
    if(o.requests&&o.requests[r.incident_id]!=null&&'sha256:'+sha256('req:'+String(o.requests[r.incident_id]).slice(0,5000))!==r.request_hash)problems.push('request_hash does not match the retained original request');
    if(problems.length)allOk=false;results.push({i,id:r.incident_id,ok:!problems.length,problems});});
  const head=chain.length?chain[chain.length-1].receipt_hash:null;
  let anchorStatus=null;
  if(o.anchor){const rec=chain.find(r=>r.incident_id===o.anchor.id);anchorStatus=!rec?'missing':(rec.receipt_hash===o.anchor.hash?'ok':'mismatch');}
  return {ok:allOk,results,head,anchorStatus,length:chain.length,brokenAt:results.filter(x=>!x.ok).map(x=>x.i)};
}
if(typeof module!=='undefined')module.exports={sha256,analyze,normalize,BENEFICIARIES,POLICIES,POLICY_META,RULES_INFO,CANARY,levelOf,hash64,buildReceipt,verifyChain,canon,GENESIS,ENGINE_VERSION,RULESET_ID};
/* ===== END ENGINE ===== */
