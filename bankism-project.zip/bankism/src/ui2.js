/* ===== shared helpers 2 ===== */
const pct=v=>v==null?'n/a':(v*100).toFixed(1)+'%';
const showInv=s=>String(s).replace(/[\u200B-\u200F\u2060\uFEFF\u00AD]/g,'⟦ZW⟧');
async function saveText(fname,txt,setMsg){
  try{if(typeof claude!=='undefined'){const d=await claude.use('downloads');if(d){await d.save({filename:fname,data:txt});setMsg&&setMsg('Saved '+fname);return;}}}catch(e){}
  try{const bl=new Blob([txt],{type:'application/json'});const u=URL.createObjectURL(bl);const a=document.createElement('a');a.href=u;a.download=fname;document.body.appendChild(a);a.click();a.remove();setMsg&&setMsg('Download started (if your viewer blocks downloads, use Copy).');}catch(e){setMsg&&setMsg('Download unavailable here — use Copy.');}
}
async function copyText(txt,setMsg){
  try{await navigator.clipboard.writeText(txt);setMsg&&setMsg('Copied to clipboard.');}catch(e){const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');setMsg&&setMsg('Copied to clipboard.');}catch(e2){setMsg&&setMsg('Copy failed — select the text manually.');}ta.remove();}
}
function Explain(props){
  const r=props.r,e=r.explain;if(!e)return null;
  let run=0;
  return h('details',{className:'explain',open:props.open},h('summary',null,'Explain this verdict'),
    div({style:{marginTop:10}},
      div({className:'banner',style:{marginBottom:10}},Ic('cpu',16),span(null,b(null,'Detection method: '),e.method,' Ruleset ',span({className:'mono'},e.ruleset),' · engine v'+(r.engineVersion||'')+'.')),
      div({className:'k'},'1 · Rules that fired'),
      e.rules.length?div({className:'tbl-wrap'},table({style:{minWidth:560}},thead(null,tr(null,['Rule','Policy','Matched text','Weight','Hard-block?'].map(x=>th({key:x},x)))),
        tbody(null,e.rules.map((x,k)=>tr({key:k,style:{cursor:'default'}},td({className:'mono'},x.id),td({className:'mono'},x.pol),td({className:'mono',style:{maxWidth:260,wordBreak:'break-word'}},showInv(x.match)),td({className:'mono'},'+'+x.weight),td(null,x.hard?span({className:'pill block'},'HARD'):span({className:'pill'},'weighted'))))))):div({style:{color:'var(--mut)'}},'No hostile-pattern rules fired.'),
      div({className:'k',style:{marginTop:12}},'2 · Score calculation'),
      r.factors.length?div({className:'tbl-wrap'},table({style:{minWidth:420}},thead(null,tr(null,['Factor','Policy','Points','Running total'].map(x=>th({key:x},x)))),
        tbody(null,r.factors.map((f,k)=>{run+=f.pts;return tr({key:k,style:{cursor:'default'}},td(null,f.label),td({className:'mono'},f.pol||'—'),td({className:'mono',style:{color:'var(--cy)'}},'+'+f.pts),td({className:'mono'},run));})))):div({style:{color:'var(--mut)'}},'No factors: score 0.'),
      div({className:'k',style:{marginTop:12}},'3 · Decision path'),
      h('ol',{className:'lst',style:{paddingLeft:18,listStyle:'decimal'}},e.path.map((p2,k)=>li({key:k,style:{display:'list-item'}},p2))),
      e.hard?div({className:'banner',style:{marginTop:10,borderColor:'rgba(248,113,113,.4)',color:'#fecaca',background:'rgba(248,113,113,.06)'}},Ic('shield',16),'Hard-block override: '+e.hardWhy.join('; ')+'. These policies set the score to at least 82 regardless of other factors.'):null));
}
